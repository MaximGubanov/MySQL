-- Задача №1
-- Создайте таблицу logs типа Archive. Пусть при каждом создании записи в таблицах users, 
-- catalogs и products в таблицу logs помещается время и дата создания записи, название таблицы, 
-- идентификатор первичного ключа и содержимое поля name.
DROP TABLE IF EXISTS logs;
CREATE TABLE logs (
	id SERIAL,
	create_at DATETIME,
	table_name CHAR(20),
	content CHAR(100) 
) ENGINE=ARCHIVE;

#Триггер для логирования таблицы users
DROP TRIGGER IF EXISTS to_logs_users;
DELIMITER //
CREATE TRIGGER to_logs_users AFTER INSERT ON users
FOR EACH ROW 
BEGIN
	SET @name = (SELECT name FROM users ORDER BY id DESC LIMIT 1);
	INSERT INTO logs (create_at, table_name, content)
	VALUES (NOW(), 'users', @name);
END//
DELIMITER ;

# Триггер для логирования таблицы catalogs
DROP TRIGGER IF EXISTS to_logs_catalogs;
DELIMITER //
CREATE TRIGGER to_logs_catalogs AFTER INSERT ON catalogs
FOR EACH ROW 
BEGIN
	SET @name = (SELECT name FROM catalogs ORDER BY id DESC LIMIT 1);
	INSERT INTO logs (create_at, table_name, content)
	VALUES (NOW(), 'catalogs', @name);
END//
DELIMITER ;

# Триггер для products
DROP TRIGGER IF EXISTS to_logs_products;
DELIMITER //
CREATE TRIGGER to_logs_products AFTER INSERT ON products
FOR EACH ROW 
BEGIN
	SET @name = (SELECT name FROM products ORDER BY id DESC LIMIT 1);
	INSERT INTO logs (create_at, table_name, content)
	VALUES (NOW(), 'products', @name);
END//
DELIMITER ;

# Для проверки
insert into users (id, name, birthday_at) 
values (13, 'Olga', '1984-11-01');

insert into catalogs (name) 
values ('Принтеры');

insert into products (name) 
values ('PlayStation4');

select * from logs;


-- Задача №2
-- (по желанию) Создайте SQL-запрос, который помещает в таблицу users миллион записей.
DROP PROCEDURE IF EXISTS add_row;
DELIMITER //
CREATE PROCEDURE add_row ()
BEGIN
	DECLARE i BIGINT DEFAULT 0;
	WHILE i < 1000000 DO
	 	INSERT INTO users (name)
		VALUES ('name');
		SET i = i + 1;
	END WHILE;
END//
DELIMITER ;

CALL add_row();

SELECT * FROM users;
TRUNCATE users;
