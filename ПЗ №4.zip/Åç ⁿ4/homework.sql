-- Задание №2
/*Написать скрипт, возвращающий список имен (только firstname) 
 пользователей без повторений в алфавитном порядке*/
SELECT DISTINCT firstname 
FROM users
ORDER BY firstname ASC;

-- Задание №3
/* Написать скрипт, отмечающий несовершеннолетних пользователей,
 как неактивных (поле is_active = false). Предварительно добавить 
 такое поле в таблицу profiles со значением по умолчанию = true (или 1)
 
Тут вопрос: как сделать проверку на существовние поля is_active?
ALTER TABLE profiles DROP COLUMN IF EXISTS is_active не работает*/
ALTER TABLE profiles
ADD is_active VARCHAR(5) DEFAULT 'true' AFTER gender; -- добавляем поле is_active с значением по умолчанию 'true' для всех пользователей

UPDATE profiles
SET is_active='false' -- устанавливем значение 'false' для несовершенолетних
WHERE (YEAR(CURRENT_DATE) - YEAR(birthday)) < 18; -- вычисляем возраст

-- Задание №4
/*Написать скрипт, удаляющий сообщения «из будущего» (дата больше сегодняшней)*/
/*надеюсь я правильно понял задание)*/
INSERT INTO messages
	(from_user_id, to_user_id, body, created_at) 
VALUES 
	('23', '54', 'Text', '2022-08-30'),
	('11', '54', 'Text', '2035-08-30'),
	('67', '24', 'Text', '2028-08-30'),
	('20', '99', 'Text', '2078-08-30')
;

DELETE FROM messages 
WHERE created_at > NOW();