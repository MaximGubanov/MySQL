CREATE DATABASE example;

USE example;

CREATE TABLE user(
	id SERIAL,
	name VARCHAR(50) NOT NULL
);