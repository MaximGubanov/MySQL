/*Задача №1
 Составьте список пользователей users, которые осуществили 
 хотя бы один заказ orders в интернет магазине.*/

# Добавил в orders несколько позиций с покупателями
insert into orders (user_id) values 
	(4), 
	(6), 
	(9);
# добавил позиции для красоты в orders_products, чтобы вывести кто - что купил
insert into orders_products (order_id, product_id, total) values 
	(4, 1, 4), 
	(6, 3, 1), 
	(9, 7, 1);
# Сам запрос
SELECT 
	u.name AS `Покупатель`,
	p.name AS `Купил`,
	p.price AS `Цена`,
	op.total AS `Кол-во`
FROM users AS u 
JOIN orders	AS o ON u.id = o.user_id 
JOIN orders_products op ON u.id = order_id
JOIN products p ON op.product_id = p.id;

/*Задача №2
 Выведите список товаров products и разделов catalogs, который соответствует товару.*/
SELECT
	p.id AS `№`, 
	p.name AS `Название товара`,
	c.name AS `Категория`
FROM products AS p
LEFT JOIN catalogs AS c ON p.catalog_id = c.id; 

/*Задача №3
 Пусть имеется таблица рейсов flights (id, from, to) и таблица городов cities (label, name). 
 Поля from, to и label содержат английские названия городов, поле name — русское. 
 Выведите список рейсов flights с русскими названиями городов.*/

DROP TABLE IF EXISTS flights;
CREATE TABLE flights (
	id SERIAL PRIMARY KEY,
	from_city VARCHAR(20),
	to_city VARCHAR(20)
);

DROP TABLE IF EXISTS cities;
CREATE TABLE cities (
	label VARCHAR(20),
	name VARCHAR(20)
); 

INSERT INTO flights (from_city, to_city)
VALUES 
	('Omsk', 'Moscow'),
	('Tambov', 'Novgorod'),
	('Moscow', 'St. Petersburg'),
	('Murmansk', 'Moscow'),
	('Moscow', 'Ekaterinburg');

INSERT INTO cities (label, name)
VALUES 
	('Omsk', 'Омск'),
	('Tambov', 'Тамбов'),
	('Moscow', 'Москва'),
	('Murmansk', 'Мурманск'),
	('Ekaterinburg', 'Екатеринбурнг'),
	('Novgorod', 'Новгород'),
	('St. Petersburg', 'Санкт Петербург');

SELECT 
	from_city.name AS `Откуда`, 
	to_city.name AS `Куда`
FROM
	(SELECT f.id, c.name 
	FROM flights AS f 
	JOIN cities AS c
	ON c.label = f.from_city) as from_city
     	JOIN
    (SELECT f.id, c.name 
	FROM flights AS f 
	JOIN cities AS c
	ON c.label = f.to_city) AS to_city
 		ON from_city.id = to_city.id
 ORDER BY from_city.id
