/* Хранимые процедуры и функции, триггеры
Задача №1
Создайте хранимую функцию hello(), которая будет возвращать приветствие, в зависимости 
от текущего времени суток. С 6:00 до 12:00 функция должна возвращать фразу "Доброе утро", 
с 12:00 до 18:00 функция должна возвращать фразу "Добрый день", с 18:00 до 00:00 — 
"Добрый вечер", с 00:00 до 6:00 — "Доброй ночи".*/

# У меня не получилось сделать через функцию, поэтому оставил как есть - через процедуру
DELIMITER // 
DROP PROCEDURE IF EXISTS hello//
CREATE PROCEDURE hello()
BEGIN
	SET @time_now = (SELECT HOUR(NOW()));
	IF (0 <= @time_now AND @time_now <= 6) THEN
		SELECT 'Доброй ночи';
	ELSEIF (6 < @time_now AND @time_now <= 12) THEN
		SELECT 'Доброе утро';
	ELSEIF (12 < @time_now AND @time_now <= 18) THEN
		SELECT 'Добрый день';
	ELSE 
		SELECT 'Добрый вечер';
	END IF;
END//
DELIMITER ;

CALL hello(); -- проверяем

/*Задача №2
 В таблице products есть два текстовых поля: name с названием товара и description 
 с его описанием. Допустимо присутствие обоих полей или одно из них. Ситуация, когда 
 оба поля принимают неопределенное значение NULL неприемлема. Используя триггеры, 
 добейтесь того, чтобы одно из этих полей или оба поля были заполнены. При попытке 
 присвоить полям NULL-значение необходимо отменить операцию.*/
DROP TRIGGER IF EXISTS check_prod;

DELIMITER //
CREATE TRIGGER check_prod BEFORE INSERT ON products
FOR EACH ROW BEGIN
	IF NEW.name IS NULL AND NEW.description IS NULL THEN
		SIGNAL SQLSTATE '45000'
		SET msg_text = "Поля не должны иметь значение NULL";
	END IF;
END//
DELIMITER ;

INSERT INTO products (name, description)
VALUES ('ASUS', 'Материнская плата');

INSERT INTO products (name, description)
VALUES (NULL, NULL);


SELECT * FROM products ORDER BY id DESC;








