/*Транзакции, переменные, представления*/
/*Задача №1
 В базе данных shop и sample присутствуют одни и те же таблицы, учебной базы данных. 
 Переместите запись id = 1 из таблицы shop.users в таблицу sample.users. 
 Используйте транзакции.*/
SET autocommit=0;
START TRANSACTION;
INSERT INTO sample.`user` (sample.user.id, sample.user.name)
SELECT vk.users.id, vk.users.firstname
FROM vk.users 
WHERE id = 1;
COMMIT;
-- TRUNCATE sample.user;
-- SELECT * FROM sample.`user` u 

/*Задача №2
 Создайте представление, которое выводит название name товарной позиции из 
 таблицы products и соответствующее название каталога name из таблицы catalogs.*/
CREATE VIEW view_products AS
SELECT 
	p.id `№`,
	p.name `Имя`,
	c.name `Категория`
FROM products p
JOIN catalogs c
ON p.catalog_id = c.id
ORDER BY p.id; 

SELECT * FROM view_products; -- проверяем





