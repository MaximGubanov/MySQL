# 1.Пусть задан некоторый пользователь. Из всех пользователей соц. сети найдите человека, 
# который больше всех общался с выбранным пользователем (написал ему сообщений).
SET @user_id = 3; -- выбираем пользователя
SELECT 
	COUNT(*) AS cnt, 
	(SELECT firstname FROM users WHERE id = from_user_id) AS `От`,
	(SELECT firstname FROM users WHERE id = @user_id) AS `Кому`
FROM messages
WHERE to_user_id = @user_id
GROUP BY from_user_id
HAVING cnt > 1
-- HAVING MAX(cnt) - почему это не работает, как отфильтровать по максимуму?
ORDER BY cnt DESC
LIMIT 1; -- пришлось поставить LIMIT


# 2. Подсчитать общее количество лайков, которые получили пользователи младше 10 лет..
SELECT 
	SUM(likes) AS `sum`
FROM likes 
WHERE id in (
	SELECT id
	FROM users
	WHERE TIMESTAMPDIFF(YEAR, birthday, NOW()) < 10
);

# 3. Определить кто больше поставил лайков (всего): мужчины или женщины.
# (я понимаю, что есть более элегантное и правильное решение, но у меня пока как-то так...
# хочеться взглянуть на правильное решение)

SELECT
	(COUNT(*)) AS `Кол-во польз`, 
	(SUM(likes)) AS `Кол-во лайков`
FROM likes 
WHERE id IN (
	SELECT id FROM users WHERE gender = 'm'
)
UNION
SELECT
	(COUNT(*)) AS `Кол-во польз`, 
	(SUM(likes)) AS `Кол-во лайков`
FROM likes 
WHERE id IN (
	SELECT id FROM users WHERE gender = 'f'
);

