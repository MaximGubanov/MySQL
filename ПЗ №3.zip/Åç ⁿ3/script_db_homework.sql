CREATE DATABASE mydb;
USE mydb;

DROP TABLE IF EXISTS news;
CREATE TABLE news (
	id SERIAL,
	user_id BIGINT UNSIGNED NOT NULL, -- те кто размещают новости
	name VARCHAR(255), -- название новости
	body text, 
	created_at DATETIME DEFAULT NOW(), -- врем публикации
	/* ниже фото, видео которое может прикрепленно к новости их так же может и не быть*/
	photo_news_id BIGINT UNSIGNED NULL,
	media_news_id BIGINT UNSIGNED NULL,
	media_type_id BIGINT UNSIGNED NOT NULL,
	like_news ENUM ('like', 'dislake'),
	FOREIGN KEY (user_id) REFERENCES users(id),
	FOREIGN KEY (media_type_id) REFERENCES media_types(id)
);

DROP TABLE IF EXISTS games;
CREATE TABLE games (
	id SERIAL,
	name VARCHAR(255),
	description TEXT NOT NULL, -- описание игры
	player_id BIGINT UNSIGNED NOT NULL, -- id игрока/пользователя
	game_genre ENUM ('arcade', 'action', 'RPG', 'strategy'),
	status_user ENUM ('online', 'offline'),
	price INT UNSIGNED NULL,
	FOREIGN KEY (player_id) REFERENCES users(id)
);

DROP TABLE IF EXISTS product; 
CREATE TABLE product (
	id SERIAL,
	name VARCHAR(255) NOT NULL, -- название
	description TEXT NOT NULL, -- описание 
	photo BIGINT UNSIGNED NOT NULL, -- фото товара
	price INT UNSIGNED NULL, -- цена
	discount INT NULL, -- скидка
	category JSON, -- категории
	quantity INT UNSIGNED NULL -- количество
);

DROP TABLE IF EXISTS market; -- онлайн магазин
CREATE TABLE market (
	id SERIAL,
	product_id BIGINT UNSIGNED NULL, -- товары
	customer_id BIGINT UNSIGNED NULL, -- покупатель
	status_pay ENUM ('paid', 'not paid'), -- оплачен/не оплачен
	FOREIGN KEY (customer_id) REFERENCES users(id),
	FOREIGN KEY (product_id) REFERENCES product(id) -- ссылка на таблицу с товарами
);