-- Практическое задание по теме “Операторы, фильтрация, сортировка и ограничение”

-- Задание №1 
-- Пусть в таблице users поля created_at и updated_at оказались незаполненными. 
-- Заполните их текущими датой и временем.
-- К существ-ей базе VK добавил два столбца.
-- ALTER TABLE users DROP COLUMN create_at, DROP COLUMN update_at;
-- Я спец-но сделал тип VARCHAR  для задачи №2.
ALTER TABLE users ADD create_at VARCHAR(50) DEFAULT NULL;
ALTER TABLE users ADD update_at VARCHAR(50) DEFAULT NULL;
-- Заполняем их текущей датой
UPDATE users
SET create_at = (SELECT DATE_FORMAT(NOW(), '%d.%m.%Y %H:%i')),
	update_at = (SELECT DATE_FORMAT(NOW(), '%d.%m.%Y %H:%i'))
WHERE id between 1 AND 100;

-- Задача №2 
-- Таблица users была неудачно спрое ктирована. Записи created_at и updated_at 
-- были заданы типом VARCHAR и в них долгое время помещались значения в формате "20.10.2017 8:10". 
-- Необходимо преобразовать поля к типу DATETIME, сохранив введеные ранее значения.
UPDATE users
SET create_at = (SELECT DATE_FORMAT(str_to_date(create_at, '%d.%m.%Y %H:%i'), '%Y-%m-%d %H:%i')),
	update_at = (SELECT DATE_FORMAT(str_to_date(update_at, '%d.%m.%Y %H:%i'), '%Y-%m-%d %H:%i'))
WHERE id BETWEEN 1 AND 100;
-- преобразуем к типу DATETIME
ALTER TABLE users 
MODIFY COLUMN create_at DATETIME,
MODIFY COLUMN update_at DATETIME;

-- Задача №3
-- В таблице складских запасов storehouses_products в поле value могут встречаться самые разные
-- цифры: 0, если товар закончился и выше нуля, если на складе имеются запасы. Необходимо 
-- отсортировать записи таким образом, чтобы они выводились в порядке увеличения значения value. 
-- Однако, нулевые запасы должны выводиться в конце, после всех записей.
CREATE TABLE storehouses_products (
	id SERIAL,
	name VARCHAR(20) DEFAULT 'name_product',
	value INT
);

INSERT INTO storehouses_products (name, value)
VALUES ('Milk', 45), ('Orange', 35), ('Bred', 78), ('Cofee', 0), ('Tea', 12), ('Oil', 0);

SELECT * 
FROM storehouses_products
ORDER BY value = 0, value;

-- Задача №4
-- (по желанию) Из таблицы users необходимо извлечь пользователей, родившихся в августе и мае. 
-- Месяцы заданы в виде списка английских названий ('may', 'august').
-- Добавление колонки birthday в vk
ALTER TABLE users ADD birthday DATETIME DEFAULT NULL AFTER phone;
-- Генерация дат
UPDATE users
SET birthday = (SELECT FROM_UNIXTIME(RAND() * 2147483647))
WHERE id BETWEEN 1 AND 101;
-- пришлось привести к типу VARCHAR
ALTER TABLE users 
MODIFY COLUMN birthday VARCHAR(20);
-- переобразую в формат типа "20 February 2012"
UPDATE users
SET birthday = (SELECT DATE_FORMAT(birthday, '%d %M %Y'))
WHERE id BETWEEN 1 AND 100;
-- сортируем
SELECT birthday FROM users
WHERE birthday LIKE '%August%' OR birthday LIKE '%May%';

-- Задача №5
-- (по желанию) Из таблицы catalogs извлекаются записи при помощи запроса. 
-- SELECT * FROM catalogs WHERE id IN (5, 1, 2); Отсортируйте записи в порядке, 
-- заданном в списке IN.
CREATE TABLE catalogs (
	id SERIAL,
	name VARCHAR(20),
	craate_at DATETIME DEFAULT NOW()
);

INSERT INTO catalogs (name) VALUES 
	('Moscow'), ('NYC'), ('Arzamas'), ('Novgorod'), ('Florida'), ('Rio'), ('Kursk');

SELECT * FROM catalogs WHERE id IN (5, 1, 2) ORDER BY id = 5 DESC, id = 1 DESC, id = 2 DESC;

-- Практическое задание теме “Агрегация данных”

-- 1. Подсчитайте средний возраст пользователей в таблице users
CREATE TABLE user_brthday (id SERIAL, birthday DATETIME);
INSERT INTO user_brthday (birthday) VALUES 
	('2012-10-02'),
	('2005-10-02'),
	('1984-10-02'),
	('1976-10-02'),
	('1999-10-02');

SELECT SUM(YEAR(CURDATE()) - YEAR(birthday)) / COUNT(1) FROM user_brthday;
-- ОТВЕТ: 25,8 лет

-- 2. Подсчитайте количество дней рождения, которые приходятся на каждый из дней недели. 
-- Следует учесть, что необходимы дни недели текущего года, а не года рождения.



-- 3. (по желанию) Подсчитайте произведение чисел в столбце таблицы
SELECT (((1 * 2) * 3) * 4) * 5; -- один из вариантов = 120
SELECT 5 * (5 - 1) * (5 - 2) * (5 - 3) * (5 - 4) * 1; -- по формуле факториала = 120






